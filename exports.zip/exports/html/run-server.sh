#!/bin/bash

xdg-open http://localhost:8000/index.html

python3 -m http.server
